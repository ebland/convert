__import__('pkg_resources').declare_namespace(__name__)
